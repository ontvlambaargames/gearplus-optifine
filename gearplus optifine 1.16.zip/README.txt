Managed by ShinyNate
------------------------

You will encounter bugs but they should not affect your ability to play. 

Please report any bugs to me at nate33730@gmail.com. Please note WHAT BLOCK the bug is on and HOW IT APPEARED. Most bugs will appear as the purple/black error texture. 

-----------------------
The packs GearPlus and MobPlus are the work of ShinyNate and permission must be obtained to use redistribute any part of this pack.
